package org.dailyactions;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class AlarmScheduler {

    public static void ensureNotificationPermission(Activity activity) {
        if (activity == null) return;
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(activity, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(activity,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10001);
            }
        }
    }

    private static String channelIdForSound(String soundName) {
        return "reminder_" + soundName; // pro Sound eigener Channel
    }

    private static void ensureChannel(Context ctx, String soundName) {
        if (Build.VERSION.SDK_INT < 26) return;

        String channelId = channelIdForSound(soundName);
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm.getNotificationChannel(channelId) != null) return;

        Uri soundUri = Uri.parse("android.resource://" + ctx.getPackageName() + "/raw/" + soundName);

        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        NotificationChannel ch = new NotificationChannel(channelId, "Reminder (" + soundName + ")",
                NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(soundUri, aa);

        nm.createNotificationChannel(ch);
    }

    public static void schedule(Context ctx, long triggerAtMs, String soundName, int requestId,
                                String title, String text) {
        if (ctx == null) return;
        if (soundName == null || soundName.isEmpty()) soundName = "bell";

        ensureChannel(ctx, soundName);
        String channelId = channelIdForSound(soundName);

        Intent i = new Intent(ctx, AlarmReceiver.class);
        i.putExtra("channelId", channelId);
        i.putExtra("title", title);
        i.putExtra("text", text);
        i.putExtra("notifId", requestId);

        PendingIntent pi = PendingIntent.getBroadcast(
                ctx, requestId, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);

        // "ungefähr reicht": setAndAllowWhileIdle ist ok (nicht "exact")
        if (Build.VERSION.SDK_INT >= 23) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
        } else {
            am.set(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
        }
    }

    public static void cancel(Context ctx, int requestId) {
        if (ctx == null) return;

        Intent i = new Intent(ctx, AlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(
                ctx, requestId, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pi);
        pi.cancel();
    }
}
